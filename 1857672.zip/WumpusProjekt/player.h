#ifndef PLAYER_H
#define PLAYER_H

#include "board.h"
#include <QObject>
#include <string>

class Player{

private:
    int xStart; //startpositions, important for resets after death
    int yStart;
    int xCoordinate; // current location
    int yCoordinate;
    Board* thisBoard; //the Board on which is played
    int points; // current Points
    void moveDirection(int dir); // movement function

public:
    void moveAlgorithm(int dir); // movement function with reaction to new Room

    Player(Board* thisBoard);
    Board *getThisBoard();

    std::string getPointsString(); // gets the displayed pointstring
    void setBack(); //sets the position to the start position(after death)
    int getPoints(); // gets the points as int
    Room* currentRoom(); // you could also acces this with thisBoard, but since we need this often this makes it easier



    int getXCoordinate() const;
    int getYCoordinate() const;
};

#endif // PLAYER_H
