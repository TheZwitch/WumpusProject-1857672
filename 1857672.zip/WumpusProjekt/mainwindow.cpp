#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setCentralWidget(ui->mainWidget);
    ui->mainWidget->setCurrentIndex(0);
    ui->mainWidget->show();
    scale = 100;
    proxy1 = gameScene->addWidget(playerOnePicture); // need these Proxys to lay the Room GUI behind the Player, also to dont destroy it when pressing the retry Button
    autoProxy = gameScene->addWidget(autoPlayerPicture);
    playerTwoProxy = gameScene->addWidget(playerTwoPicture);
    playerOnePalette.setColor(QPalette::WindowText, Qt::blue);//color of Player One / Player Two related messages
    playerTwoPalette.setColor(QPalette::WindowText, Qt::red);
    ui->pointLabel->setPalette(playerOnePalette);
    gameEnd =0;
    this->setWindowTitle("Wumpusadventure by Tarek Zwick, 1857672");


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::updatePoints()
{
    this->ui->pointLabel->setText("P1: " + QString::fromStdString( this->PlayerOne->getPointsString()));
    if(secondPlayer) ui->playerTwoCurrentPoints->setText("P2: " + QString::fromStdString( this->PlayerTwo->getPointsString()));
}


void MainWindow::on_startButton_clicked()
{
    gameScene->addItem(autoProxy);//adding and removing them is important, so they don't get deletet when the User chooses to not use them in the first run.
    gameScene->removeItem(autoProxy);//if the User presses retry, and now chooses them for the second run, we get a segmentation fault if these lines are missing
    gameScene->addItem(playerTwoProxy); // sorry for that much confusing GUI library code btw, this isn't that easy to understand (for me it wasn't understandable at all one week ago)
    gameScene->removeItem(playerTwoProxy);
    ui->showButton->setText("Show all");
    eventTimerPlayerOne = 0;

    currentPlayer = 1;
    if(ui->collectorModeCheckBox->isChecked()) collectorMode = 1;
    else collectorMode = 0;
    if(ui->respawnCheckBox->isChecked()) respawnOn = 1;
    else collectorMode = 0;
    Board *thisBoard = new Board(ui->sizeAdjustor->value());// size Adjustor is the SPinBox in which you enter the Board Size
    if(ui->NPCCeckbox->isChecked()){
        autoPlayerOne = new automaticPlayer(thisBoard,7);
        this->autoPlayer=1;
    }else this->autoPlayer=0;
    if(ui->playerTwoCheckBox->isChecked()){
        PlayerTwo = new LocalPlayer(thisBoard);
        this->secondPlayer=1;
        this->ui->playerTwoCurrentPoints->show();
        ui->playerTwoCurrentPoints->setPalette(playerTwoPalette);
            eventTimerPlayerTwo = 0;
    }else{
        this->ui->playerTwoCurrentPoints->hide();
        this->secondPlayer=0;
    }
    ui->playerTwoLastRoomEvent->hide();
    ui->playerOneLastRoomEvent->hide();
    PlayerOne= new LocalPlayer(thisBoard);
    ui->mainWidget->setCurrentIndex(1);
    this->generateGUI();

}








void MainWindow::on_leftButton_clicked() // WASD movement is made with shortcuts to these buttons (in the xml/ ui_mainwindow.h)
{
    if(currentPlayer == 1){
    try{
    PlayerOne->moveAlgorithm(1);
    }catch(int i){roomEvent(i, PlayerOne);}
    }else if (currentPlayer == 2){
        try{
        PlayerTwo->moveAlgorithm(1);
        }catch(int i){roomEvent(i, PlayerTwo);}

    }
    if( !gameEnd) this->nextPlayer();


}


void MainWindow::on_rightButton_clicked()
{
    if(currentPlayer == 1){
    try{
    PlayerOne->moveAlgorithm(3);
    }catch(int i){roomEvent(i, PlayerOne); }
    } else if (currentPlayer ==2){
        try{
        PlayerTwo->moveAlgorithm(3);
        }catch(int i){roomEvent(i, PlayerTwo);}

    }
    if(!gameEnd) this->nextPlayer();


}
    void MainWindow::on_upButton_clicked()
    {
        if(currentPlayer ==1){
        try{
            PlayerOne->moveAlgorithm(2);

        }
        catch(int i){roomEvent(i, PlayerOne);}
        } else if (currentPlayer == 2 ){
            try{
            PlayerTwo->moveAlgorithm(2);
            }catch(int i){roomEvent(i, PlayerTwo);}

        }
        if( !gameEnd)this->nextPlayer();

    }

void MainWindow::on_downButton_clicked()
{
    if(currentPlayer ==1){
    try{
    PlayerOne->moveAlgorithm(4);
    }catch(int i){roomEvent(i, PlayerOne);}
    }else if(currentPlayer == 2){
        try{
        PlayerTwo->moveAlgorithm(4);
        }catch(int i){roomEvent(i, PlayerTwo);}
    }
    if(!gameEnd) this->nextPlayer();




}


void MainWindow::roomEvent(int i, Player *thisPlayer)
{
    this->updateGUI(0, 0, thisPlayer); // pit/Wumpus gets updatet before reset
    if(thisPlayer == PlayerOne){
         this->ui->playerOneLastRoomEvent->show();
           if(autoPlayer && !secondPlayer) eventTimerPlayerOne = 3; // set so the label stays until the next LocalPlayer action
           else eventTimerPlayerOne = 2;
       }
    if(thisPlayer == PlayerTwo){
           this->ui->playerTwoLastRoomEvent->show();
           if(autoPlayer) eventTimerPlayerTwo = 3;
           else eventTimerPlayerTwo = 2;
       }
    if(i==1){
        if(thisPlayer == PlayerOne) ui->playerOneLastRoomEvent->setText("WALKED AGAINST A WALL!");
        if(thisPlayer == PlayerTwo) ui->playerTwoLastRoomEvent->setText("WALKED AGAINST A WALL!");
    }

    if(i == 3){ // 3 is a Pit
        thisPlayer->setBack();
        if(thisPlayer == PlayerOne) ui->playerOneLastRoomEvent->setText("FELL IN PIT");
        if(thisPlayer == PlayerTwo) ui->playerTwoLastRoomEvent->setText("FELL IN PIT");
    }
    if( (i == 4 && !respawnOn && !( secondPlayer && thisPlayer == autoPlayerOne))|| (i == 5 && (!collectorMode || this->PlayerOne->getThisBoard()->getGoldNumber() == 1))){ //4 is a wumpus, 5 Gold
        setGameResults(i, thisPlayer, collectorMode);

    }else if(i==4 && respawnOn){
        thisPlayer->setBack();

        if(thisPlayer == PlayerOne) ui->playerOneLastRoomEvent->setText("WAS EATEN");
        if(thisPlayer == PlayerTwo) ui->playerTwoLastRoomEvent->setText("WAS EATEN");
    }
    if(i== 5 && collectorMode){
        thisPlayer->getThisBoard()->setGoldNumber(thisPlayer->getThisBoard()->getGoldNumber() -1);
        thisPlayer->currentRoom()->setRoomProperty(0);
        thisPlayer->getThisBoard()->resetAdjacencies();
        thisPlayer->getThisBoard()->setRoomAdjacencies();
        updateGUI(1,shown,PlayerOne);
        if(this->autoPlayer) this->updatePlayerPosition(autoPlayerOne);
        if(this->secondPlayer) this->updatePlayerPosition(PlayerTwo);
        if(thisPlayer == PlayerOne){
            eventTimerPlayerOne++;
            ui->playerOneLastRoomEvent->setText("FOUND GOLD");
        }
        if(thisPlayer == PlayerTwo){
            eventTimerPlayerOne++;
            ui->playerTwoLastRoomEvent->setText("FOUND GOLD");
        }
    }
}





void MainWindow::on_retryButton_clicked()
{
this->retry();

}


void MainWindow::retry(){

    gameScene->removeItem(proxy1); // clear deletes everything in the scene, we need the playerPicture later on so we remove it before
    if(autoPlayer) gameScene->removeItem(autoProxy); // ther sadly is no easier way to remove a widget without deleting it then the proxy thingdelete PlayerOne->getThisBoard();
    if(secondPlayer) gameScene->removeItem(playerTwoProxy);// if I delete it, we will get a big segmentation fault when trying to acces PlayerPicture
    delete PlayerOne->getThisBoard();
    autoPlayer = 0;
    secondPlayer = 0;
    gameEnd = 0;
    shown = 0;
    this->gameScene->clear();
    this->ui->mainWidget->setCurrentIndex(0); // opens the menu
}

void MainWindow::updateGUI(bool drawAll, bool seeAll, Player* thisPlayer)
{
    updatePoints();
    updateRooms(drawAll, seeAll, thisPlayer);
    PlayerOne->currentRoom()->setKnown(true);
    updatePlayerPosition(thisPlayer);
    if(secondPlayer) updatePlayerState();

    if(eventTimerPlayerOne == 1){ // updates the eventLabels next to the Point labels so they dissapear after a certain time
        eventTimerPlayerOne = 0;
        ui->playerOneLastRoomEvent->hide();
    }
    if(eventTimerPlayerOne >= 2) eventTimerPlayerOne --;
    if(eventTimerPlayerTwo == 1){
        eventTimerPlayerTwo = 0;
        ui->playerTwoLastRoomEvent->hide();
    }
    if(eventTimerPlayerTwo >= 2) eventTimerPlayerTwo --;

}

void MainWindow::updateRooms(bool drawAll, bool seeAll, Player* thisPlayer)
{


    if(drawAll){
    this->gameScene->removeItem(proxy1); // as in retry said we dont want to delete the players
    if(autoPlayer) this->gameScene->removeItem(autoProxy);
    if(secondPlayer) this->gameScene->removeItem(playerTwoProxy);
    this->gameScene->clear(); // only should be done when we want to redraw everything, the Player is redrawn afterwards in updatePlayerPosition
    }
    for(int x = 0; x <= thisPlayer->getThisBoard()->getSize(); x++){
        for(int y = 0; y <= thisPlayer->getThisBoard()->getSize(); y++){
            if(!drawAll){ // only update the required Room
                x = thisPlayer->getXCoordinate();
                y = thisPlayer->getYCoordinate();
            }
            if(drawAll){
                QGraphicsRectItem *rect = new QGraphicsRectItem(this->scale * x, this->scale*y, this->scale, this->scale);//draws emptyRooms
                gameScene->addItem(rect); // draws the Rectangles of the empty Room
            }

            Room * room = thisPlayer->getThisBoard()->getRoom(x,y);
            if((room->getKnown() && drawAll) || seeAll ||  ((!room->getKnown()) && (room == thisPlayer->currentRoom()))){ //Room only gets drawn when 1. the Player is there and doesn't know it allready
                                                                                                            //2. we want to explicitly seel all or 3. we redraw and knew it allready
                QPixmap roomGraphics;                                                                        // we get low memory use because only the necessary ones are drawn
                QLabel * pictureLabel = new QLabel();
                if(room->getRoomProperty() == 1)  roomGraphics.load("Graphics/pit.png");                //these load the right room Graphic
                else if(room->getRoomProperty() == 2) roomGraphics.load("Graphics/wumpus.png");   //if you use the Qt library and manage to run this Projekt
                else if(room->getRoomProperty() == 3) roomGraphics.load("Graphics/gold.png");       // you will have to replace these with the right Path on your PC
                else if( room->getPitNearby()){
                    if(room->getWumpusNearby()){
                        if(room->getGoldNearby())  roomGraphics.load("Graphics/stench+glitter+breeze.png");
                        else roomGraphics.load("Graphics/stench+breeze.png");
                    }
                    else if (room->getGoldNearby()) roomGraphics.load("Graphics/glitter+breeze.png");
                    else if( room->getPitNearby()) roomGraphics.load("Graphics/breeze.png");
                }
                else if(room->getWumpusNearby()){
                    if(room->getGoldNearby())roomGraphics.load("Graphics/stench+glitter.png");
                    else roomGraphics.load("Graphics/stench.png");
                }
                else if(room->getGoldNearby()) roomGraphics.load("Graphics/glitter.png");
                else roomGraphics.fill(Qt::transparent);
                thisPlayer->currentRoom()->setKnown(1);

                pictureLabel->setStyleSheet("background-color:transparent;");
                pictureLabel->setGeometry(QRect(room->getXRoom()*scale +1, room->getYRoom()*scale + 1, scale -2, scale -2)); // places the Label which displays the picture in the right spot and manages the size
                pictureLabel->setPixmap(roomGraphics.scaled(scale - 2,scale -2,Qt::KeepAspectRatio)); // loads the Pixmap into the label which displays the picture
                this->gameScene->addWidget(pictureLabel);
                pictureLabel->stackUnder(playerOnePicture); //needed so the Player Graphics arent hidden behind the Room Graphics
                if(autoPlayer)pictureLabel->stackUnder(autoPlayerPicture);
                if(secondPlayer) pictureLabel->stackUnder(playerTwoPicture);
            }
            if(!drawAll){
                x = thisPlayer->getThisBoard()->getSize() + 1;
                y = thisPlayer->getThisBoard()->getSize() + 1; // breaks loop when only the new Room needs to be drawn
        }
    }
}
}



void MainWindow::updatePlayerPosition(Player *thisPlayer){

    if(thisPlayer == PlayerOne){
        playerOnePicture->setGeometry(QRect(thisPlayer->getXCoordinate()*scale+ 0.15*scale, thisPlayer->getYCoordinate()*scale + 0.05*scale, scale*0.6, scale*0.9)); //sets Geometry of PlayerPicture
        gameScene->removeItem(proxy1);
        gameScene->addItem(proxy1); // somehow the stackUnder command (in update Room) only works when I add the PlayerPicture per proxy as QItem. Took me a while to figure out, but if you
                                    // don't do that the Player will be hidden behind the Roompictures. Also gotta remove and add him every time, the stackUnder alone somehow doesnt work
    }else if (thisPlayer == autoPlayerOne){  // the remove and add on its own doesnt work ether
        autoPlayerPicture->setGeometry(QRect(thisPlayer->getXCoordinate()*scale+ 0.29*scale, thisPlayer->getYCoordinate()*scale + 0.05*scale, scale*0.42, scale*0.9));
        gameScene->removeItem(autoProxy);
        gameScene->addItem(autoProxy);

    }
    else if(thisPlayer == PlayerTwo){
        playerTwoPicture->setGeometry(QRect(thisPlayer->getXCoordinate()*scale+ 0.15*scale, thisPlayer->getYCoordinate()*scale + 0.05*scale, scale*0.6, scale*0.9));
        gameScene->removeItem(playerTwoProxy);
        gameScene->addItem(playerTwoProxy);
    }

}

void MainWindow::generateGUI(){
    QPixmap PlayerGraphic;
    ui->currentPlayerLabel->hide();
    PlayerGraphic.load("Graphics/playerOne.png"); // loads Player Graphics in Pixmap
    playerOnePicture->setGeometry(QRect(PlayerOne->getXCoordinate()*scale+ 0.15*scale, PlayerOne->getYCoordinate()*scale + 0.05*scale, scale*0.6, scale*0.9));
    playerOnePicture->setStyleSheet("background-color:transparent;"); // needet so the label around the Player isnt filled with white (we wouldn't see the rooms)
    playerOnePicture->setPixmap(PlayerGraphic.scaled(playerOnePicture->width(), playerOnePicture->height(),  Qt::KeepAspectRatio)); // loads Pixmap in Label, with right scales
    this->updateGUI( 1, 0, PlayerOne);
    if(autoPlayer){
        autoPlayerPicture->setGeometry(QRect(autoPlayerOne->getXCoordinate()*scale+ 0.29*scale, autoPlayerOne->getYCoordinate()*scale + 0.05*scale, scale*0.42, scale*0.9));
         PlayerGraphic.load("Graphics/autoPlayerOne.png");
         autoPlayerPicture->setStyleSheet("background-color:transparent;");
         autoPlayerPicture->setPixmap(PlayerGraphic.scaled(autoPlayerPicture->width(), autoPlayerPicture->height(),  Qt::KeepAspectRatio));
         this->gameScene->addItem(autoProxy);
         this->updateGUI(0, 0, autoPlayerOne);
    }
    if(secondPlayer){
        playerTwoPicture->setGeometry(QRect(PlayerTwo->getXCoordinate()*scale+ 0.15*scale, PlayerTwo->getYCoordinate()*scale + 0.05*scale, scale*0.6, scale*0.9));
         PlayerGraphic.load("Graphics/playerTwo.png");
         playerTwoPicture->setStyleSheet("background-color:transparent;");
         playerTwoPicture->setPixmap(PlayerGraphic.scaled(playerTwoPicture->width(), playerTwoPicture->height(),  Qt::KeepAspectRatio));
         this->gameScene->addItem(playerTwoProxy);
         this->updateGUI(0, 0, PlayerTwo);
         ui->currentPlayerLabel->show();
         gameScene->addItem(playerTwoProxy);
         updatePlayerState();

    }
     updatePoints();
     updatePlayerPosition(PlayerOne); // so the Player One (i.e. current Player at the start) is in front of the others when multiple are in the same startroom
     ui->gameWindow->setScene(gameScene);

}

void MainWindow::updatePlayerState() // displays who is the current Player
{
    QFont thisFont("Arial",19, QFont::Bold, Qt::AlignCenter);
    QPalette palette;
    if(currentPlayer ==1 ){
         palette.setColor(QPalette::WindowText, Qt::blue);
        ui->currentPlayerLabel->setText("PLAYER ONE");
    }else if (currentPlayer == 2){
       palette.setColor(QPalette::WindowText, Qt::red);
       ui->currentPlayerLabel->setText("PLAYER TWO");
    }
    ui->currentPlayerLabel->setFont(thisFont);
    ui->currentPlayerLabel->setPalette(palette);

}

void MainWindow::setGameResults(int i, Player* thisPlayer, bool winByPoints) // sets game results ether due to the button press or due to the winning condition beeing reached
{                                                                          // also has to examine the winning condition, so it is given to it (i)
    gameEnd = 1;
    QFont endScreenFont("End", 40, QFont::Bold, Qt::AlignCenter);
    ui->gameOverPoints->setFont(endScreenFont);
    ui->statusLabel->setFont(endScreenFont);
    ui->statusLabel->setAlignment(Qt::AlignCenter);
    ui->gameOverPoints->setAlignment(Qt::AlignCenter); // set up Point Label for PlayerOne
    ui->gameOverPoints->setText("Player One Points: " + QString::fromStdString(PlayerOne->getPointsString()));

    ui->gameOverPoints->setPalette(playerOnePalette);
    if(autoPlayer){         //set up Point Label for autoPlayer
        QPalette autoPlayerOnePalette;
        autoPlayerOnePalette.setColor(QPalette::WindowText, Qt::green);
        ui->autoPlayerPoints->setAlignment(Qt::AlignCenter);
        ui->autoPlayerPoints->show();
        ui->autoPlayerPoints->setText("Autoplayer Points: "  +QString::fromStdString(autoPlayerOne->getPointsString()));
        ui->autoPlayerPoints->setFont(endScreenFont);
    }else ui->autoPlayerPoints->hide();
    if(secondPlayer){ // set up Point Label for PlayerTwo
        ui->playerTwoPoints->setPalette(playerTwoPalette);
        ui->playerTwoPoints->setAlignment(Qt::AlignCenter);
        ui->playerTwoPoints->setText("Player Two Points: "  +QString::fromStdString(PlayerTwo->getPointsString()));
        ui->playerTwoPoints->setFont(endScreenFont);
        ui->playerTwoPoints->show();

    }else ui->playerTwoPoints->hide();

    if(!secondPlayer && !autoPlayer){
        if( i == 5) ui->statusLabel->setText("VICTORY");
        else  ui->statusLabel->setText("GAME OVER");
    }
    else if(!secondPlayer){
        if( (i == 4 && this->PlayerOne == thisPlayer || i==5 && thisPlayer == autoPlayerOne  && !winByPoints) ||( winByPoints && autoPlayerOne->getPoints() > PlayerOne->getPoints())) ui->statusLabel->setText("GAME OVER");
        else ui->statusLabel->setText("VICTORY");
        ui->playerTwoPoints->hide();
                ui->mainWidget->setCurrentIndex(2);
    }else{
        if(!winByPoints){     //win either through player death or gold finding
            if ((i == 4 && thisPlayer ==PlayerTwo) || (i == 5 && thisPlayer == PlayerOne)) ui->statusLabel->setText( " PLAYER ONE WINS");
            if ((i == 4 && thisPlayer ==PlayerOne) || (i == 5 && thisPlayer == PlayerTwo)) ui->statusLabel->setText( " PLAYER TWO WINS");
            if  ( i == 5 && thisPlayer == autoPlayerOne) ui->statusLabel->setText("YOU BOTH GOT ANIHILATED BY THE BEST BOT EVER");
        }else if( autoPlayer){ // this one is for the collector mode
            if(PlayerOne->getPoints() > PlayerTwo->getPoints() && PlayerOne->getPoints() >= autoPlayerOne->getPoints())  ui->statusLabel->setText( " PLAYER ONE WINS");
            else if( PlayerTwo->getPoints() > PlayerOne->getPoints() && PlayerTwo->getPoints() >= autoPlayerOne->getPoints()) ui->statusLabel->setText( " PLAYER TWO WINS");
            else if( autoPlayerOne->getPoints() > PlayerOne->getPoints() && autoPlayerOne->getPoints() > PlayerTwo->getPoints()) ui->statusLabel->setText("YOU BOTH GOT ANIHILATED BY THE BEST BOT EVER");
            else ui->statusLabel->setText("DRAW...");
        }else{ //this one is for collector mode without auto Player
            if(PlayerOne->getPoints() > PlayerTwo->getPoints())  ui->statusLabel->setText( " PLAYER ONE WINS");
            else if( PlayerTwo->getPoints() > PlayerOne->getPoints()) ui->statusLabel->setText( " PLAYER TWO WINS");
            else ui->statusLabel->setText("DRAW...");
        }

    }
    ui->mainWidget->setCurrentIndex(2);
    if(!respawnOn && i==4 && thisPlayer == autoPlayerOne){
        gameScene->removeItem(autoProxy);
        this->autoPlayer = 0;


    ui->mainWidget->setCurrentIndex(2);

}

}
void MainWindow::on_showButton_clicked()
{
    if(!shown){
    this->updateGUI(1,1, PlayerOne);
    if(this->autoPlayer) this->updatePlayerPosition(autoPlayerOne);
    if(this->secondPlayer) this->updatePlayerPosition(PlayerTwo);
    shown = 1;
    ui->showButton->setText("Hide");
    }else{
        this->updateGUI(1, 0, PlayerOne);
        if(this->autoPlayer) this->updatePlayerPosition(autoPlayerOne);
        if(this->secondPlayer) this->updatePlayerPosition(PlayerTwo);
        shown = 0;
        ui->showButton->setText("Show all");
    }

}


void MainWindow::on_scaleSlider_sliderMoved(int position)
{
    this->scale = position*3;
    this->generateGUI(); // can't do this with the whole map shown, it will lagg to hard, so thats the reason why the map dissapears when this one is called

}
void MainWindow::nextPlayer(){
    if(this->currentPlayer == 1){
        if(this->secondPlayer){
            currentPlayer = 2;
            updateGUI(0,0, PlayerOne);
        }
        else if(this->autoPlayer){
            currentPlayer = 3;
            updateGUI(0,0, PlayerOne);
            try{
            autoPlayerOne->autoMove();
            }catch(int i){roomEvent(i, autoPlayerOne); }
            nextPlayer();
        }

        if(this->secondPlayer) this->updatePlayerPosition(PlayerTwo); // so the current Player is in front of the others if multiple are in one Room
        }
    else if(this->currentPlayer == 2){
        if(this->autoPlayer){
            currentPlayer = 3;
            updateGUI(0,0, PlayerTwo);
            try{
            autoPlayerOne->autoMove();
            }catch(int i){roomEvent(i, autoPlayerOne); }
            nextPlayer();
        }
        else{

            currentPlayer = 1;
            updateGUI(0,0, PlayerTwo);
        }
        if(!this->autoPlayer) updatePlayerPosition(PlayerOne) ;
    }
    else if(currentPlayer == 3){
            currentPlayer = 1;
            updateGUI(0,0, autoPlayerOne);
            this->updatePlayerPosition(PlayerOne);

        }
}










void MainWindow::on_finishButton_clicked()
{
    setGameResults(0, PlayerOne,1);

}

