#include "board.h"

int Board::getSize() const
{
    return size;
}

Room *Board::findFreeRoom()
{
    int x;
    int y;
    do{
        x = QRandomGenerator::global()->bounded(1, this->getSize());
        y = QRandomGenerator::global()->bounded(1, this->getSize());
    }while(this->getRoom(x,y)->getRoomProperty() != 0);
    return this->getRoom(x,y);
}

int Board::getGoldNumber() const
{
    return goldNumber;
}

void Board::setGoldNumber(int newGoldNumber)
{
    goldNumber = newGoldNumber;
}

void Board::setRoomAdjacencies() //looks for every Rooms properties and then sets the Adjacencies for every adjacent Room
{
    for(int x=0; x <= this->size; x++){
        for(int y = 0; y <= this->size; y++){
            int currentProperty = roomX[x][y]->getRoomProperty();
            if( currentProperty != 0){
                if(x > 0) roomX[x-1][y]->adjacenceAdd(currentProperty);
                if (x < this->size) roomX[x+1][y]->adjacenceAdd(currentProperty);
                if(y > 0 )roomX[x][y-1]->adjacenceAdd(currentProperty);
                if(y < this->size) roomX[x][y+1]->adjacenceAdd(currentProperty);
            }
        }
    }
}

void Board::resetAdjacencies()
{    for(int x=0; x <= this->size; x++){
        for(int y = 0; y <= this->size; y++){
           roomX[x][y]->resetAdjacencies();
        }
    }

}

Board::Board(int size) : size(size-1){ // this->size is the size of the vector, since the vector starts at 0, this is the board size -1( makes the logic later easier)

    int emptyRooms = 0;
    goldNumber = 0;
    for(int x = 0; x <= this->size; x++){
        std::vector<Room*> roomY;
        for(int y = 0; y <= this->size; y++){

            int newProperty = 0;
            int random = 40;
            if( emptyRooms >= ((x*(this->size) + y)*0.4))random = QRandomGenerator::global()->bounded(1, 40); // makes it so at least 2/5 of the rooms are empty ( not considering gold, one wumpus and player)
            if(random <= 7) newProperty = 1;                                                          //originally wanted to make the odds the same as in the example you gave, but due to the failsafe
            else if(random == 9 || random == 10) newProperty = 2;                                         //wich prevents that every Room is full I had to rebalance
            else if(random == 11){
                if(goldNumber <= ((x*(this->size) + y)*0.05 && this->size <= 10) ){  // theres a maximum for Gold that can be generated
                    newProperty = 3;
                    goldNumber++;
                }
                else if(goldNumber <= ((x*(this->size) + y)*0.0375 && this->size <= 20) ){
                    newProperty = 3;
                    goldNumber++;
                }
                else if(goldNumber <= ((x*(this->size) + y)*0.025) ){
                    newProperty = 3;
                    goldNumber++;
                }
            }
            else{
                newProperty = 0;
                emptyRooms ++;
            }
            roomY.push_back(new Room(newProperty,x,y));
        }
        roomX.push_back(roomY);


    }
    for(goldNumber; goldNumber <= (size / 10); goldNumber++)  this->findFreeRoom()->setRoomProperty(3); //at least 1 gold every 10 size( not every 100 rooms for difficulty increase with board size)
    this->findFreeRoom()->setRoomProperty(2); //want to have at least one wumpus
    setRoomAdjacencies();

}
Room* Board::getRoom(int x, int y){
    return roomX[x][y];
}

