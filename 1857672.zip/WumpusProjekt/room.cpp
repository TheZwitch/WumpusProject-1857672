#include "room.h"

int Room::getRoomProperty() const
{
    return roomProperty;
}

void Room::setRoomProperty(int newRoomProperty)
{
    roomProperty = newRoomProperty;
}


Room::Room()
{

}



void Room::adjacenceAdd(int newAdjacence)
{
    if (this->roomProperty == 0){
    if(newAdjacence == 1)this->pitNearby =1;
    if(newAdjacence == 2)this->wumpusNearby =1;
    if(newAdjacence == 3)this->goldNearby =1;
    }
}
int Room::getXRoom() const
{
    return xRoom;
}

void Room::setXRoom(int newXRoom)
{
    xRoom = newXRoom;
}

int Room::getYRoom() const
{
    return yRoom;
}

void Room::setYRoom(int newYRoom)
{
    yRoom = newYRoom;
}

bool Room::getKnown() const
{
    return known;
}

void Room::setKnown(bool newKnown)
{
    known = newKnown;
}

bool Room::getWumpusNearby() const
{
    return wumpusNearby;
}

bool Room::getPitNearby() const
{
    return pitNearby;
}

bool Room::getGoldNearby() const
{
    return goldNearby;
}

void Room::resetAdjacencies()
{
    this->wumpusNearby = 0;
    this->goldNearby = 0;
    this->pitNearby = 0;
}

Room::Room(int roomProperty, int x, int y) : roomProperty(roomProperty), xRoom(x), yRoom(y)
{
    known = 0;
    wumpusNearby = 0;
    pitNearby = 0;
    goldNearby = 0;

}
