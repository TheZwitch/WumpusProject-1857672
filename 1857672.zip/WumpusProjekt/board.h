#ifndef BOARD_H
#define BOARD_H
#include "room.h"
#include <QRandomGenerator>


class Board
{
private:
    std::vector<std::vector<Room*>> roomX;
    int size;
    int goldNumber; // number of Rooms with Gold
public:
    Board(int size);
    Room* getRoom(int x,int y);
    int getRoomX (Room*);

    int getSize() const;
    Room* findFreeRoom(); // returns an empty Room of this Board

    int getGoldNumber() const;
    void setGoldNumber(int newGoldNumber);
    void setRoomAdjacencies(); // sets the adjacencies of every Room (i.e. wind, smell, glitter)
    void resetAdjacencies(); //deletes all the adjacencies
};

#endif // BOARD_H
