#include "automaticplayer.h"


automaticPlayer::automaticPlayer(Board *thisBoard, int scanRange) :scanRange(scanRange), Player(thisBoard)
{
    step = 0;
    stuck = 0;
}

void automaticPlayer::autoMove()
{
float pointsDir1 = 0;// rating of direction 1 (left)
bool dir1 = 1; //determins wether this direction is viable or not
float pointsDir2 = 0;
bool dir2 =1; // up
float pointsDir3 = 0;
bool dir3 = 1; //right
float pointsDir4 = 0;
bool dir4 = 1; // down
if(this->getXCoordinate()> 0) pointsDir1=expandetRating(currentRoom(), getXCoordinate()-1,getYCoordinate(), 0);
else pointsDir1 = -2000; // so it doesn't walk at walls, cant do this with dir1 = 0 because the ifs might set every dir=0 then
if(this->getXCoordinate() < this->getThisBoard()->getSize()) pointsDir3 = expandetRating(currentRoom(), getXCoordinate()+1, getYCoordinate(), 0);
else pointsDir3 = -2000;
if(this->getYCoordinate()> 0) pointsDir2=expandetRating(currentRoom(), getXCoordinate(),getYCoordinate()-1, 0);
else pointsDir2 = -2000;
if (this->getYCoordinate() <this->getThisBoard()->getSize()) pointsDir4 = expandetRating(currentRoom(),getXCoordinate(), getYCoordinate()+1, 0);
else pointsDir4 = -2000;
if((pointsDir1 < pointsDir2) || (pointsDir1 < pointsDir3) || (pointsDir1 < pointsDir4)) dir1 = 0;
if((pointsDir2 < pointsDir1) || (pointsDir2 < pointsDir3) || (pointsDir2 < pointsDir4)) dir2 = 0;
if((pointsDir3 < pointsDir1) || (pointsDir3 < pointsDir2) || (pointsDir3 < pointsDir4)) dir3 = 0;
if((pointsDir4 < pointsDir1) || (pointsDir4 < pointsDir2) || (pointsDir4 < pointsDir3)) dir4 = 0;
lastRoom = currentRoom();


if (stuck == 3){
    stuck = 6;
}
if (stuck >=3){
    stuck -= 2;
    moveRandom((pointsDir1 > -1000) , (pointsDir2 > -1000) , (pointsDir3 > -1000), (pointsDir4 > -1000)); // activates the random mode for two steps if one random move doesnt work when stuck
}
else if((step == 2 ||step == 4 || step == 6)&& (this->getXCoordinate() == xTwoSteps) && (this->getYCoordinate() == yTwoSteps)){

     if(step == 4){
         moveRandom((pointsDir1 > -400) , (pointsDir2 > -400) , (pointsDir3 > -400), (pointsDir4 > -400)); //prevents getting stuck between two rooms, still not walking into walls tho
        stuck ++;
     }else {
         stuck++;
         moveRandom(dir1, dir2, dir3, dir4);
     }
}
else{
     if(step==2 || step == 4 || step == 6) stuck =0;
    moveRandom(dir1, dir2, dir3, dir4);
}

if (step == 6) {
    xTwoSteps = this->getXCoordinate();
    yTwoSteps = this->getYCoordinate();
    step = 0;
}
else step ++;
}





float automaticPlayer::expandetRating(Room *callingRoom,int x, int y,int depthOfAnalysis){
    float retVal = 0;

    Room* thisRoom = this->getThisBoard()->getRoom(x,y);
    if(depthOfAnalysis == 0){
        analyzedRoom = thisRoom;
        allKnown = 1;

    }
    if(!thisRoom->getKnown()) allKnown = 0;
    if(thisRoom->getKnown()){
        float pitRelevance = 0.5;
        if(depthOfAnalysis == 1) pitRelevance = 3;
        if (thisRoom->getPitNearby()&& depthOfAnalysis == 1 && !analyzedRoom->getKnown() ||thisRoom->getPitNearby()&& depthOfAnalysis == 0){
            if(!nearbyPit(thisRoom))retVal -= 5 * pitRelevance;
            else retVal -= 1*pitRelevance;

        }
         if(thisRoom->getWumpusNearby() && depthOfAnalysis == 1 && !analyzedRoom->getKnown() || (thisRoom->getWumpusNearby() && depthOfAnalysis == 0 && !nearbyKnown(thisRoom)))// wumpus is only relevant when the Rooms around the primary Room are smelly and it isnt known
         { //also the autoPlayer just turns around when in a smelly Room with unknown adcjacents, so just don't go there in the first place

             if(!nearbyWumpus(thisRoom))retVal -=70;
             else retVal -= 3;
         }
         if(thisRoom->getWumpusNearby() && 1 <  depthOfAnalysis && !nearbyKnown(thisRoom) && !nearbyWumpus(thisRoom))  retVal -=1; // don't just run at wumpuses if you have other options. But it's not that bad and sometimes needet => low number
         if(thisRoom->getGoldNearby() && depthOfAnalysis <= 1) retVal += 75;
         if(thisRoom->getGoldNearby() && depthOfAnalysis > 1){
             retVal += pow(3.8, depthOfAnalysis) *(75-(50*( depthOfAnalysis/(scanRange)))); //Gold far away is interesting to some extent, the exponent nearly cancels out the *0.2 ^depthofAnalysis of the recursion,and the subtraction makes sure gold further away isn't that valuable
         }      //useless most of the times because the gold further away will alwais be collected by the Player who found it
        if(thisRoom->getRoomProperty() == 1 && depthOfAnalysis == 0) retVal-= 100; // don't run into pits

        if(thisRoom->getRoomProperty()== 2){  // don't run into known Wumpuses
            if(depthOfAnalysis == 0) retVal-= 300;
            else if(depthOfAnalysis <= 5) retVal -= 5; // pretty much no influence considering the *0.2 ^depthofAnalysis of the recursion, but will prevent running into a wall of Wumpuses sometimes
        }
    }
    if(this->currentRoom()->getWumpusNearby() && thisRoom->getKnown() && depthOfAnalysis == 0 && thisRoom->getRoomProperty() != 1 && !nearbyWumpus(thisRoom)) retVal += 100; //prefers known Rooms when in a smelly Room
    if(this->currentRoom()->getGoldNearby() && thisRoom->getKnown() && depthOfAnalysis == 0) retVal -= 130; // prefers unknown Rooms when in glittery Room
    if(thisRoom->getKnown() && depthOfAnalysis == 0) retVal -= 10; //prefers unknown Rooms in general
    else if(thisRoom->getKnown() && depthOfAnalysis == 1) retVal -= 3;
    else if(thisRoom->getKnown() && depthOfAnalysis <= 4) retVal -= 3;
    if(depthOfAnalysis <= scanRange && !(thisRoom->getKnown() && thisRoom->getRoomProperty() == 1 || thisRoom->getKnown() && thisRoom->getRoomProperty() == 2)){ //don't need to further analyse when the way is blocked
        depthOfAnalysis ++;
        if(x>0){ //look if the next Room even exists
            if(!(thisRoom->getWumpusNearby()&& !this->getThisBoard()->getRoom(x-1,y)->getKnown() || callingRoom == getThisBoard()->getRoom( x-1, y))){ // dont analyse further when the current Room is smelly and the next one unknown or the Room was analyzed before
            if( depthOfAnalysis == 1)retVal += expandetRating(thisRoom, x-1, y, depthOfAnalysis );
             else retVal += (std::pow(0.27, depthOfAnalysis)* expandetRating(thisRoom, x-1, y, depthOfAnalysis));
            }
        }
        else if(depthOfAnalysis <= 1) retVal -= 5; // walls are ineffective to search
        if(x< getThisBoard()->getSize()){
            if(!(thisRoom->getWumpusNearby()&& !this->getThisBoard()->getRoom(x+1,y)->getKnown() || callingRoom == getThisBoard()->getRoom( x+1, y))){
                if( depthOfAnalysis == 1)retVal += expandetRating(thisRoom, x+1, y, depthOfAnalysis );
                else retVal += (std::pow(0.27, depthOfAnalysis)* expandetRating(thisRoom, x+1, y, depthOfAnalysis));
            }
        }
        else if (depthOfAnalysis <= 1) retVal -= 5;
        if(y>0){
            if(!(thisRoom->getWumpusNearby()&& !this->getThisBoard()->getRoom(x,y-1)->getKnown() || callingRoom == getThisBoard()->getRoom( x, y-1))){
                if( depthOfAnalysis == 1)retVal += expandetRating(thisRoom, x, y-1, depthOfAnalysis);
                else retVal += (std::pow(0.27, depthOfAnalysis) * expandetRating(thisRoom, x, y-1, depthOfAnalysis));
            }
        }
        else if(depthOfAnalysis <= 1) retVal -=5;
        if(y< getThisBoard()->getSize()){
            if(!(thisRoom->getWumpusNearby()&& !this->getThisBoard()->getRoom(x,y+1)->getKnown() || callingRoom == getThisBoard()->getRoom( x, y+1))){
                if( depthOfAnalysis == 1)retVal += expandetRating(thisRoom, x, y+1, depthOfAnalysis );
                else retVal += (std::pow(0.27, depthOfAnalysis) * expandetRating(thisRoom, x, y+1, depthOfAnalysis ));
            }
        }
        else if(depthOfAnalysis <= 1) retVal -= 5;
    }
    else if(allKnown &&thisRoom == analyzedRoom && thisRoom->getWumpusNearby()) retVal -= 175; // this one is used so the autoPlayer doesn't get stuck in a corner with the only way out beeing a smelly room
    if(allKnown &&depthOfAnalysis == 1 && thisRoom->getWumpusNearby()) retVal+= 80;
    if(analyzedRoom==thisRoom && !(currentRoom()->getWumpusNearby() && !nearbyWumpus(currentRoom()) && !nearbyKnown(currentRoom()) || analyzedRoom->getGoldNearby())&& thisRoom == lastRoom) retVal -= 50; //don't go back and forth between two rooms
    return retVal;

}


void automaticPlayer::moveRandom(bool dir1, bool dir2, bool dir3, bool dir4)
{
    int random = 0;

    if(dir1 + dir2 + dir3 + dir4 >= 2){
            random = QRandomGenerator::global()->bounded(1, 4);
    }else{
        if(dir1) random = 1;
        if(dir2) random = 2;
        if (dir3) random = 3;
        if( dir4) random = 4;
    }

    if(random == 1 && dir1) this->moveAlgorithm(1);
    else if(random == 2 && dir2) this->moveAlgorithm(2);
    else if(random == 3 && dir3) this->moveAlgorithm(3);
    else if(random == 4 && dir4) this->moveAlgorithm(4);
    else this->moveRandom(dir1, dir2, dir3, dir4);
}

bool automaticPlayer::nearbyKnown(Room *thisRoom) // if nearby Rooms are known you can use the smelly one to get from the one to the other
{
    int known =0;
    int x = thisRoom->getXRoom();
    int y = thisRoom->getYRoom();
    if(x > 0 ){
        if(this->getThisBoard()->getRoom(x-1, y)->getKnown() && !(this->getThisBoard()->getRoom(x-1,y)->getRoomProperty() == 2)) known++;
    }
    if(x < this->getThisBoard()->getSize()){
        if(this->getThisBoard()->getRoom(x+1, y)->getKnown()&& !(this->getThisBoard()->getRoom(x+1,y)->getRoomProperty() == 2)) known++;
    }
    if(y > 0){
        if(this->getThisBoard()->getRoom(x, y-1)->getKnown() && !(this->getThisBoard()->getRoom(x,y-1)->getRoomProperty() == 2)) known++;
    }
    if (y < this->getThisBoard()->getSize()){
        if(this->getThisBoard()->getRoom(x, y+1)->getKnown() && !(this->getThisBoard()->getRoom(x, y+1)->getRoomProperty() == 2)) known++;
    }
    if(known >= 2) return true;
    else return false;

}

bool automaticPlayer::nearbyPit(Room *thisRoom)// if the Room is windy but a known pit is nearby, it doesn matter in most cases, that's what this one is needed for
{
    bool retVal = 0;
    int x = thisRoom->getXRoom();
    int y = thisRoom->getYRoom();
    if(x > 0 ){
        if(this->getThisBoard()->getRoom(x-1, y)->getKnown()&& this->getThisBoard()->getRoom(x-1,y)->getRoomProperty() == 1) retVal = 1;
    }
    if(x < this->getThisBoard()->getSize()){
        if(this->getThisBoard()->getRoom(x+1, y)->getKnown()&& this->getThisBoard()->getRoom(x+1,y)->getRoomProperty()== 1) retVal = 1;
    }
    if(y > 0){
        if(this->getThisBoard()->getRoom(x, y-1)->getKnown()&& this->getThisBoard()->getRoom(x,y-1)->getRoomProperty() == 1) retVal = 1;
    }
    if (y < this->getThisBoard()->getSize()){
        if(this->getThisBoard()->getRoom(x, y+1)->getKnown()&& this->getThisBoard()->getRoom(x,y+1)->getRoomProperty() == 1) retVal = 1;
    }
    return retVal;
}

bool automaticPlayer::nearbyWumpus(Room *thisRoom) // if the Room is smelly but a known Wumpus is nearby, it doesn matter in most cases, that's what this one is needed for
{
    bool retVal = 0;
    int x = thisRoom->getXRoom();
    int y = thisRoom->getYRoom();
    if(x > 0 ){
        if(this->getThisBoard()->getRoom(x-1, y)->getKnown()&& this->getThisBoard()->getRoom(x-1,y)->getRoomProperty() == 2) retVal = 1;
    }
    if(x < this->getThisBoard()->getSize()){
        if(this->getThisBoard()->getRoom(x+1, y)->getKnown()&& this->getThisBoard()->getRoom(x+1,y)->getRoomProperty()== 2) retVal = 1;
    }
    if(y > 0){
        if(this->getThisBoard()->getRoom(x, y-1)->getKnown()&& this->getThisBoard()->getRoom(x,y-1)->getRoomProperty() == 2) retVal = 1;
    }
    if (y < this->getThisBoard()->getSize()){
        if(this->getThisBoard()->getRoom(x, y+1)->getKnown()&& this->getThisBoard()->getRoom(x,y+1)->getRoomProperty() == 2) retVal = 1;
    }
    return retVal;
}



