#include "player.h"
#include <QRandomGenerator>


Player::Player( Board* thisBoard) : thisBoard(thisBoard)
{
    Room* startRoom = thisBoard->findFreeRoom(); // this is the startposition

    this->xCoordinate = startRoom->getXRoom();
    this->xStart = startRoom->getXRoom();
    this->yCoordinate = startRoom->getYRoom();
    this->yStart = startRoom->getYRoom();
    this->points = 0;


}

Board *Player::getThisBoard()
{
    return thisBoard;
}




std::string Player::getPointsString()
{
    return std::to_string(points) + " Points" ;
}
int Player::getPoints(){
    return this->points;
}

void Player::setBack()
{
    this->xCoordinate = this->xStart;
    this->yCoordinate = this->yStart;
}



int Player::getXCoordinate() const
{
    return xCoordinate;
}

int Player::getYCoordinate() const
{
    return yCoordinate;
}

void Player::moveDirection(int dir){
    if(dir==1){
        if(this->xCoordinate != 0) this->xCoordinate -= 1; //Player goes left
        else throw(1); //thrown when a wall blocks the way
    }
    if(dir==2){
        if(this->yCoordinate != 0) this->yCoordinate -= 1; //Player goes up
        else throw(1);
    }
    if(dir==3){
        if(this->xCoordinate != this->thisBoard->getSize()) this->xCoordinate += 1; //Player goes right
        else throw(1);
    }
    if(dir==4){
        if(this->yCoordinate != this->thisBoard->getSize()) this->yCoordinate += 1; //Player goes down
        else throw(1);
    }
}

Room *Player::currentRoom()
{
    return this->getThisBoard()->getRoom(this->xCoordinate, this->yCoordinate);
}
void Player::moveAlgorithm(int dir){ //this one chatches the movement errors and reacts to the new Room
     this->moveDirection(dir);

    if(this->thisBoard->getRoom(xCoordinate, yCoordinate)->getRoomProperty()==1){
        this->points -=10;
        throw 3;
    }
    if(this->thisBoard->getRoom(xCoordinate, yCoordinate)->getRoomProperty()==2){
        this->points -=1000;
        throw 4;
    }
    if(this->thisBoard->getRoom(xCoordinate, yCoordinate)->getRoomProperty()==3){
        this->points +=1000;
        throw 5;
    }

}
