#ifndef LOCALPLAYER_H
#define LOCALPLAYER_H

#include "player.h"
class LocalPlayer : public Player{
                                     // this one really only exist because it is required in the Task
                                    //the reason I don't need it is because the movement is via GUI. Every Function this one needs, is also needed by the automatic Player
                                     // normally I wouldn't create this, but since I'm doing this one for the Grades, here it is
public:    LocalPlayer(Board *thisBoard);
};

#endif // LOCALPLAYER_H


inline LocalPlayer::LocalPlayer(Board *thisBoard) : Player(thisBoard)
{}

